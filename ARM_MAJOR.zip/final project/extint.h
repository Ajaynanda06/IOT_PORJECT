#ifndef _EXTINT_H_
#define _EXTINT_H_

void eint0_isr(void) __irq;
void Enable_EINT0(void);

#endif
